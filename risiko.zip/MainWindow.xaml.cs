﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media;
using System.Windows.Shapes;

namespace risiko
{
    /// <summary>
    /// Logica di interazione per MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Dictionary<string, Territorio> mappaTerritori = new Dictionary<string, Territorio>();
        public MainWindow()
        {
            InitializeComponent();



        }
        private void AggiornaColoriMappa()
        {
            // 1. Creiamo i due pennelli con trasparenza
            SolidColorBrush pennelloAmico = new SolidColorBrush(Color.FromArgb(120, 0, 255, 0));   // Verde semi-trasparente
            SolidColorBrush pennelloNemico = new SolidColorBrush(Color.FromArgb(120, 255, 0, 0));   // Rosso semi-trasparente

            // 2. Usiamo un ciclo foreach per passare in rassegna ogni territorio nel dizionario
            foreach (KeyValuePair<string, Territorio> elemento in mappaTerritori)
            {
                string nomeStato = elemento.Key;   // Es. "Francia", "Spagna"
                Territorio territorio = elemento.Value;

                // 3. Cerchiamo il poligono corrispondente nella grafica usando il nome "poly" + nomeStato
                // (Assicurati che in XAML i poligoni si chiamino polyFrancia, polySpagna, ecc.)
                Polygon poligonoGrafico = this.FindName("poly" + nomeStato) as Polygon;

                // Se il poligono esiste nella schermata, lo coloriamo
                if (poligonoGrafico != null)
                {
                    if (territorio.getProprietario() == "Giocatore 1")
                    {
                        poligonoGrafico.Fill = pennelloAmico;
                    }
                    else
                    {
                        poligonoGrafico.Fill = pennelloNemico;
                    }
                }
            }
        }
    }
}
