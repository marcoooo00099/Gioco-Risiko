﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace risiko
{
    internal class Territorio
    {
        private string nome;
        private int potenza;
        private string proprietario;

        public Territorio(string nome, int potenza, string proprietario)
        {
            this.nome = nome;
            this.potenza = potenza;
            this.proprietario = proprietario;
        }




        public string getNome()
        {
            return this.nome;
        }

        public int getPotenza()
        {
            return this.potenza;
        }

        public string getProprietario()
        {
            return this.proprietario;
        }





        public void setPotenza(int nuovaPotenza)
        {
            this.potenza = nuovaPotenza;
        }

        public void aggiungiArmate(int quantita)
        {
            this.potenza += quantita;
        }

        public void rimuoviArmate(int quantita)
        {
            this.potenza -= quantita;
            if (this.potenza < 0)
            {
                this.potenza = 0;
            }
        }

        public void setProprietario(string nuovoProprietario)
        {
            this.proprietario = nuovoProprietario;
        }
    }
}